#!/bin/sh

sleep 5

\cp -rf ../../utils/AUTOUPDATE/AutoUpdate_ ../../utils/AUTOUPDATE/AutoUpdate

exit 0
