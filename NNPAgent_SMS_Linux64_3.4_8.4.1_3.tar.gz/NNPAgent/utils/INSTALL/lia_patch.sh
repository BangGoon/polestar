#!/bin/sh

lia_check=`cat ../conf/MasterAgent.conf | grep liaagentctl | grep LIAAgent | wc -l`
echo "lia_check="$lia_check
if [ $lia_check -ge 2 ] ; then
    exit 0
fi

lia_check=`ls -al ../../LIAAgent/bin/LIAAgentInstall.sh | wc -l`
if [ $lia_check -ne 1 ] ; then
    exit 0
fi

mkdir -p ../../LIAAgent/aproc
mkdir -p ../../LIAAgent/aproc/inv
mkdir -p ../../LIAAgent/aproc/resp
mkdir -p ../../LIAAgent/aproc/shell
mkdir -p ../../LIAAgent/log
mkdir -p ../../LIAAgent/conf

CUR_PATH=`pwd`
cd ../..
NNP_PATH=`pwd`

lia_check=`ls -al ./LIAAgent/conf/LIAAgent.conf | wc -l`
if [ $lia_check -ne 1 ] ; then
    \cp -rf  ./LIAAgent/conf/LIAAgent.conf_patch ./LIAAgent/conf/LIAAgent.conf
fi

cd ..
LIA_PATH=`pwd`

./NNPAgent/LIAAgent/bin/LIAAgentInstall.sh 2 $LIA_PATH 7.x

exit 0
